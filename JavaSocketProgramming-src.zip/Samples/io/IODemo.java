package io;

import java.io.*;
import javax.swing.JButton;

public class IODemo {

  public static void main(String[] args) {
    IODemo dm = new IODemo();

    // Read/Write from/to console
    String msg = dm.readConsoleInput();
    dm.printMessage(msg);

    // Write object to file;
    JButton b = new JButton("Say Hello");
    dm.writeObjectToFile("d:\\obj.dat", b);

    // Read object to from;
    JButton b2 = (JButton) dm.readObjectFromFile("d:\\obj.dat");
    System.out.println("Loaded button: " + b2.getText());


    msg = "This is an \n"
        + "IO demo program";

    // Write string to a text file
       dm.writeTextFile("d:\\demo.txt", msg);

    // Read string from a text file
   String str = dm.readTextFile("d:\\demo.txt");
   System.out.println("Read from file: " + str);

   String str2 = dm.readTextFile2("d:\\demo.txt");
   System.out.println("Read from file another way: " + str2);

  }

  public String readConsoleInput() {
    BufferedReader kybd = new BufferedReader(new InputStreamReader(System.in));
    try {
      System.out.println("Input a message:");
      String msg = kybd.readLine();
      return msg;
    }
    catch (IOException ex) {
      System.out.println(ex);
      return "";
    }
  }

  public void writeObjectToFile(String fileName, Object object) {
    try {
      FileOutputStream fout = new FileOutputStream(fileName);
      ObjectOutputStream oos = new ObjectOutputStream(fout);
      oos.writeObject(object);
      oos.close();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * Return the 1st obj in the file
   * @param fileName String
   * @return Object
   */
  public Object readObjectFromFile(String fileName) {
    try {
      FileInputStream fin = new FileInputStream(fileName);
      ObjectInputStream ois = new ObjectInputStream(fin);
      // return the 1st obj in the file
      Object obj = ois.readObject();
      ois.close();
      return obj;
    }
    catch (Exception e) {
      e.printStackTrace();
      return null;
    }
    finally {
    }
  }

  public void writeTextFile(String fileName, String contain) {
    FileOutputStream outStream = null;
    try {
      outStream = new FileOutputStream(fileName);
      for (int i = 0; i < contain.length(); ++i) {
        outStream.write(contain.charAt(i));
      }
      outStream.flush();
    }
    catch (Exception ex) {
      System.out.println(ex.getMessage());
    }
    finally {
      try {
        if (outStream != null)
          outStream.close();
      }
      catch (Exception ex) {}
    }
  }

  public void writeTextFile2(String fileName, String contain) {
    FileOutputStream fileStream = null;
    try {
      fileStream = new FileOutputStream(fileName);
      PrintStream outStream = new PrintStream(fileStream);
      outStream.println(contain);
      outStream.flush();
    }
    catch (Exception ex) {
      System.out.println(ex.getMessage());
    }
    finally {
      try {
        if (fileStream != null)
          fileStream.close();
      }
      catch (Exception ex) {}
    }
  }

  public String readTextFile(String fileName) {
    StringBuffer result = new StringBuffer("");
    FileInputStream f1 = null;
    try {
      f1 = new FileInputStream(fileName);
      boolean eof = false;
      while (!eof) {
        int c = f1.read();
        if (c == -1)
          eof = true;
        else {
          result.append( (char) c);
        }
      }
    }
    catch (Exception ex) {
    }
    finally {
      try {
        if (f1 != null)
          f1.close();
      }
      catch (Exception ex) {}
    }
    return new String(result);
  }

  public String readTextFile2(String fileName) {
    StringBuffer result = new StringBuffer("");
    FileInputStream f1 = null;
    try {
      f1 = new FileInputStream(fileName);
      BufferedReader reader = new BufferedReader(new InputStreamReader(f1));
      while (true) {
        String line = reader.readLine();
        if (line == null) {break;}
        result.append(line + "\n");
      }
    }
    catch (IOException ex) {
      ex.printStackTrace();
    }
    finally {
      try {
        if (f1 != null)
          f1.close();
      }
      catch (Exception ex) {}
    }
    return new String(result);
  }

  public void printMessage(String msg) {
    OutputStream os = System.out;
    PrintStream ps = new PrintStream(os);
    ps.println(msg);
  }
}
