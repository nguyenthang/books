import java.util.LinkedList;
import java.util.Random;

public class SampleThread {
	public static void main(String[] args) {
		Producer p = new Producer();
		Consumer c = new Consumer(p.getDataList());
		p.start();
		new Thread(c).start();
	}
}

class Producer extends Thread {
	private LinkedList dataList = new LinkedList();

	public LinkedList getDataList() {
		return dataList;
	}

	public void run() {
		final int MAX_DATA = 3;
		int value = 100;
		while (true) {
			try {
				sleep(400 + value);
			} catch (InterruptedException ex) {
				ex.printStackTrace();
			}
			int loopTime = (value % 3) + 1;
			for (int i = 0; i < loopTime; i++) {
				if (dataList.size() >= MAX_DATA) {
					System.out.println("Data queue is full!");
					continue;
				}

				Random rd = new Random();
				value = rd.nextInt(100);
				System.out.println("Generating next data: " + value);
				synchronized (dataList) {
					dataList.add(new Integer(value));
					dataList.notify();
				}
			}
		}
	}
}

class Consumer implements Runnable {
	public LinkedList dataList;

	public Consumer(LinkedList dataList) {
		this.dataList = dataList;
	}

	public void setDataList(LinkedList data) {
		this.dataList = data;
	}

	public void run() {
		if (dataList == null) {
			return;
		}
		while (true) {
			int data = getData();
			processData(data);
		}
	}

	private void processData(int data) {
		try {
			Thread.currentThread().sleep(160 + new Random().nextInt(100));
		} catch (InterruptedException ex) {
		}
		System.out.println("Processing data: " + data);
	}

	private int getData() {
		synchronized (dataList) {
			int data = 0;
			if (dataList.isEmpty()) {
				try {
					System.out.println("Data list is empty! waiting...");
					dataList.wait();
				} catch (InterruptedException ex) {
					ex.printStackTrace();
				}
			}

			if (!dataList.isEmpty()) {
				data = ((Integer) dataList.removeFirst()).intValue();
			}
			return data;
		}
	}
}