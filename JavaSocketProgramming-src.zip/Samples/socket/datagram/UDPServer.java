package datagram;

import java.io.*;
import java.net.*;

class UDPServer {
  public static void main(String args[]) throws Exception {

    final int serverPort = 9876;
    DatagramSocket serverSocket = new DatagramSocket(serverPort);
    System.out.println("Server started");

    byte[] receiveData = new byte[1024];
    byte[] sendData = new byte[1024];

    while (true) {
      DatagramPacket receivePacket =
          new DatagramPacket(receiveData, receiveData.length);

      serverSocket.receive(receivePacket);

      // Get message from client
      StringBuilder sb = new StringBuilder();
      for (int i = 0; i < receiveData.length; i++) {
        if (receiveData[i] == 0) {
          break;
        }
        sb.append((char)receiveData[i]);
      }
      String msg = sb.toString();

      // Extract address from the packet
      InetAddress IPAddress = receivePacket.getAddress();

      int clientPort = receivePacket.getPort();

      // Prepare the msg for sending
      String capitalized = msg.toUpperCase();

      sendData = capitalized.getBytes();

      DatagramPacket sendPacket =
          new DatagramPacket(sendData, sendData.length, IPAddress,
                             clientPort);

      serverSocket.send(sendPacket);
    }
  }
}

