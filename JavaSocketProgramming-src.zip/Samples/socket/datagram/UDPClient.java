package datagram;

import java.io.*;
import java.net.*;

public class UDPClient {
  public static void main(String args[]) throws Exception {
    final int port = 9876;

    BufferedReader keyboard =
        new BufferedReader(new InputStreamReader(System.in));

    DatagramSocket clientSocket = new DatagramSocket();

    InetAddress addr = InetAddress.getByName("localhost");

    byte[] sendData = new byte[1024];
    byte[] receiveData = new byte[1024];

    System.out.println("Input a message:");
    String msg = keyboard.readLine();
    sendData = msg.getBytes();

    DatagramPacket sendPacket =
        new DatagramPacket(sendData, sendData.length, addr, port);

    //Send data to server
    clientSocket.send(sendPacket);

    // Receive data from server
    DatagramPacket receivePacket =
        new DatagramPacket(receiveData, receiveData.length);

    clientSocket.receive(receivePacket);

    StringBuilder sb = new StringBuilder();
    for (int i = 0; i < receiveData.length; i++) {
      if (receiveData[i] == 0) {
        break;
      }
      sb.append((char)receiveData[i]);
    }
    String serverMsg = sb.toString();

    System.out.println("FROM SERVER:" + serverMsg);
    clientSocket.close();
  }
}
