package echo;

import java.io.*;
import java.net.Socket;
import java.net.*;

/**
 *
 * <p>Title: Java socket programming</p>
 *
 * <p>Description: Demo program</p>
 *
 * <p>Copyright: Copyright (c) 2008</p>
 *
 * <p>Company: </p>
 *
 * @author Tin, Bui Huy
 * @version 1.0
 *
 * Create a socket connect to echo service on a server.
 * Echo server port is 7. When a message is sent to this service,
 * it will be echoed back to the client
 */
public class EchoClientSocket {

  String msg = "";
  String serverAddr = "localhost";
  public EchoClientSocket(String serverAddr) {
    this.serverAddr = serverAddr;
  }

  public void readInput() {
    BufferedReader kybd = new BufferedReader(new InputStreamReader(System.in));
    try {
      msg = kybd.readLine();
    }
    catch (IOException ex) {
      System.out.println(ex);
    }
  }

  public void connectServer() {
    // create socket to connect to echo service
    Socket socket = null;
    try {
      socket = new Socket(serverAddr, 7);

      BufferedReader in = new BufferedReader(
          new InputStreamReader(
              socket.getInputStream()));
      PrintStream out = new PrintStream(socket.getOutputStream());
      readInput();
      // send a message to server
      out.println(msg);

      // retrieve echo message from server
      String echoMsg = in.readLine();
      System.out.println("Echoed: " + echoMsg);
    }
    catch (UnknownHostException ex) {
      System.out.println(ex);
    }
    catch (IOException ex) {
      System.out.println(ex);
    }
    finally {
      try {
        if (socket != null)
          socket.close();
      }
      catch (IOException exc) {
        /* terminate gracefully */
      }
    }
  }

  public static void main(String[] args) {
    String serverAddr = "localhost";
    if (args.length > 0) {
      serverAddr = args[0];
    }
    EchoClientSocket es = new EchoClientSocket(serverAddr);
    es.connectServer();
  }
}
