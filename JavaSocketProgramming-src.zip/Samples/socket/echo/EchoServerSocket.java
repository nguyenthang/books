package echo;

import java.net.*;
import java.io.*;

public class EchoServerSocket {

  public static void main(String[] args) {
    int port = 7;
    try {
      // create a server socket
      ServerSocket socket = new ServerSocket(port);

      int count = 0;

      while (true) {
        System.out.println("Served time:" + count);

        Socket incommingSocket = socket.accept();
        count++;

        // get input from socket
        BufferedReader in = new BufferedReader(new InputStreamReader(incommingSocket.getInputStream()));

        // get output to socket
        PrintStream out = new PrintStream(incommingSocket.getOutputStream());

        // now get input from the server until it closes
        String msg = in.readLine();

        // Send the message back to the client
        out.print("Echo: " + msg);
        incommingSocket.close();
      }
    }
    catch (IOException ex) {}
  }
}
