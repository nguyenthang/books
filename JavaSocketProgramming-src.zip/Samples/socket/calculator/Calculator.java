package calculator;

import java.net.*;
import java.io.*;
import java.util.*;

public class Calculator
    extends Thread {

  Socket socket;
  public Calculator(Socket socket) {
    this.socket = socket;
  }

  public void run() {
    try {
      // get input from socket
      BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

      // get output to socket
      PrintStream out = new PrintStream(socket.getOutputStream());
      // now get input from the server until it closes the

      // The message will be in this format <a mumber>[|<a number>]* e.g. 23|45|13
      String msg = in.readLine();
      // convert to a readable format
      StringTokenizer stk = new StringTokenizer(msg, "|");

      double result = 0;

      while (stk.hasMoreTokens()) {
        double number = Double.parseDouble(stk.nextToken());
        result += number;
      }

      // send the result back to the client
      out.printf(result + "");
      out.flush();
    }
    catch (IOException ex) {
      System.out.println("Error while processing data");
    }
    catch (NumberFormatException ex) {
      System.out.println("Invalid data");
    }
    finally {
      // always close the socket
      if (socket != null) {
        try {
          socket.close();
        }
        catch (IOException ex1) {
          // do nothing
        }
      }
    }
  }
}
