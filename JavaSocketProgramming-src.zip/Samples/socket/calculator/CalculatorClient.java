package calculator;

import java.util.*;
import java.io.*;
import java.net.Socket;
import java.net.*;

public class CalculatorClient {
  int serverPort;
  String serverAddr;

  LinkedList<Double> operands = new LinkedList<Double> ();

  public CalculatorClient(String serverAddr, int serverPort) {
    this.serverPort = serverPort;
    this.serverAddr = serverAddr;
  }

  public void input() {
    System.out.println("Please provide a list of numbers separated by spaces");
    BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
    String inputStr = null;
    try {
      inputStr = reader.readLine();
      StringTokenizer stk = new StringTokenizer(inputStr);
      stk.countTokens();
      while (stk.hasMoreTokens()) {
        operands.add(new Double(stk.nextToken()));
      }
    }
    catch (IOException ex) {
      System.out.println("Error while reader data");
    }
  }

  public void calculate() {
    Socket socket = null;
    try {

      socket = new Socket(serverAddr, serverPort);

      // Alternative way for stream writer
      // BufferedWriter out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));

      PrintStream out = new PrintStream(socket.getOutputStream());

      BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

      String msg = createMassege();
      out.println(msg);
      out.flush();

      String msgFromServer = in.readLine();

      System.out.println("Sum = " + msgFromServer);
    }
    catch (UnknownHostException ex) {
    }
    catch (IOException ex) {
    } finally {
      // always close the socket
        if (socket != null) {
          try {
            socket.close();
          }
          catch (IOException ex1) {
            // do nothing
          }
        }
    }
  }

  private String createMassege() {
    final String SEPARATOR = "|";
    StringBuffer msg = new StringBuffer("");
    while (!operands.isEmpty()) {
      Double operand = operands.remove(); //Retrieves and removes the first element
      msg.append(operand.toString() + SEPARATOR);
    }
    return msg.toString();
  }
}
