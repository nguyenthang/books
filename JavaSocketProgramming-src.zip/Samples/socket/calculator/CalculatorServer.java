package calculator;

import java.net.*;
import java.io.*;

public class CalculatorServer {
  int port = 8205;

  public CalculatorServer(int port) {
    this.port = port;
  }

  public CalculatorServer() {}

  public void start() {
    try {
      ServerSocket socket = new ServerSocket(port);
      System.out.println("Server started");
      while (true) {
       Socket incommingSocket =  socket.accept();
       Calculator c = new Calculator(incommingSocket);
       c.start();
      }
    }
    catch (IOException ex) {
    }
  }
}
