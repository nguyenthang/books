package calculator;

public class ServerMain {
  public static void main(String[] args) {
    CalculatorServer server = null;

    if (args.length != 0) {
      int port = Integer.parseInt(args[0]);
      server = new CalculatorServer(port);
    }
    else {
      server = new CalculatorServer();
    }
    server.start();
  }
}
