package calculator;

public class ClientMain {
  public static void main(String[] args) {
    String serverAddr = "localhost";
    int serverPort = 8205;

    if (args.length > 0) {
      serverAddr = args[0];
    }
    if (args.length > 1) {
      serverPort = Integer.parseInt(args[1]);
    }
    CalculatorClient client = new CalculatorClient(serverAddr, serverPort);
    client.input();
    client.calculate();
  }
}
