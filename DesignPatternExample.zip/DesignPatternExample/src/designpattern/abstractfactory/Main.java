package designpattern.abstractfactory;

public class Main {

    public static void main(String[] args) {
        PizzaStore s1 = new PizzaStore(new ChicagoFoodFactory());
        s1.orderPizza();
        s1.orderHotdog();

        PizzaStore s2 = new PizzaStore(new NewYorkFoodFactory());
        s2.orderPizza();
        s2.orderHotdog();
    }
}
