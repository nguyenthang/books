package designpattern.abstractfactory;

public interface FoodFactory {
    Pizza createPizza();
    Hotdog createHotdog();
}

