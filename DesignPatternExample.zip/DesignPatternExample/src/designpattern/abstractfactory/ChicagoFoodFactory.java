package designpattern.abstractfactory;

public class ChicagoFoodFactory implements FoodFactory {

        public Pizza createPizza() {
        return new ChicagoPizza();
    }

    public Hotdog createHotdog() {
        return new ChicagoHotdog();
    }
}

class ChicagoPizza implements Pizza {

    public ChicagoPizza() {
        System.out.println("A ChicagoPizza created!");
    }
}

class ChicagoHotdog implements Hotdog {

    public ChicagoHotdog() {
        System.out.println("A ChicagoHotdog created!");
    }
}


