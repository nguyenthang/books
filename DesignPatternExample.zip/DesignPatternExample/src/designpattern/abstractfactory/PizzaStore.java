package designpattern.abstractfactory;

public class PizzaStore {

    FoodFactory factory;

    public PizzaStore(FoodFactory factory) {
        this.factory = factory;
    }

    public Pizza orderPizza() {
        Pizza pizza = factory.createPizza();
        bake(pizza);
        box(pizza);
        return pizza;
    }

    public Hotdog orderHotdog() {
        Hotdog hotdog = factory.createHotdog();
        bake(hotdog);
        box(hotdog);
        return hotdog;
    }

    private void bake(Item item) {
        System.out.println("The item has been baked!");
    }

    private void box(Item item) {
        System.out.println("The item has been boxed!");
    }
}

