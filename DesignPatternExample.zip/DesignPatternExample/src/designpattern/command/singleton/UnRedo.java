package designpattern.command.singleton;

import designpattern.command.Command;
import java.util.List;
import java.util.ArrayList;

/**
 * This is a singleton class
 */
public class UnRedo {

    private static UnRedo instance;
    // private static final int MAX_UNDO_LIST = 10;
    private List<Command> undoStack = new ArrayList<Command>();
    private List<Command> redoStack = new ArrayList<Command>();

    // We should also have some code to deal with the maximum length of un/redo stacks

    public static UnRedo getInstance() {
        if (instance == null) {
           instance = new UnRedo();
        }
        return instance;
    }

    public void undo() {
        if (undoStack.isEmpty()) {
            System.out.println("Undo stack is empty!");
            return;
        }
        Command c = (Command) undoStack.remove(0);
        c.unExecute();
        redoStack.add(0, c);
    }

    public void redo() {
        if (redoStack.isEmpty()) {
            System.out.println("Redo stack is empty!");
            return;
        }
        Command c = (Command) redoStack.remove(0);
        c.execute();
        undoStack.add(0, c);
    }

    public void addCommand(Command c) {
        for (Command command : undoStack) {
            if (command == c) {
                // already added
                return;
            }
        }
        
        undoStack.add(0, c);
    }
}
