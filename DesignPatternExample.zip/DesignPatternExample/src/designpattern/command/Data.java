package designpattern.command;

public class Data implements Cloneable {
    private int position = 0;
    private String text = "";

    public Data(int position, String text) {
        this.position = position;
        this.text = text;
    }

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    @Override
    protected Data clone() throws CloneNotSupportedException {
        return (Data) super.clone();
    }

}
