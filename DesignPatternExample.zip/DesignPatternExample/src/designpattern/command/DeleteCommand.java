package designpattern.command;

import javax.swing.JTextArea;

public class DeleteCommand implements Command {

    private JTextArea textArea;
    private Data data;

    public DeleteCommand(JTextArea textArea) {
        this.textArea = textArea;
    }


    public Data updateData() {
        if (textArea.getSelectedText() == null) {
            System.out.println("No text seleted for deleting!");
            data = null;
            return data;
        }
        data = new Data(textArea.getSelectionStart(), textArea.getSelectedText());
        return data;
    }

    public void setData(Data data) {
        this.data = data;
    }

    public Data getData() {
        return data;
    }

    public void execute() {
        if (data == null ) {
            return;
        }

        textArea.replaceRange("", data.getPosition(), data.getPosition() + data.getText().length());
        System.out.println("\' " + data.getText() + "\' deleted at " + data.getPosition() + "!");
    }

    public void unExecute() {
        if (data== null) {
            return;
        }
        textArea.insert(data.getText(), data.getPosition());
        System.out.println("\'" + data.getText() + "\' inserted at " + data.getPosition() + "!");
    }

    @Override
    public DeleteCommand clone() throws CloneNotSupportedException {
        return (DeleteCommand) super.clone();
    }
}
