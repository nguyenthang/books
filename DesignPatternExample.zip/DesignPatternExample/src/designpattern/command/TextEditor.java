package designpattern.command;

import designpattern.command.singleton.UnRedo;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class TextEditor extends JFrame {

    public TextEditor() {
        JPanel contentPane = (JPanel)this.getContentPane();
        BorderLayout borderLayout = new BorderLayout();
        JToolBar toolBar = new JToolBar();
        JScrollPane scrollPane = new JScrollPane();
        final JTextArea textView = new JTextArea();
        JLabel warningLabel =
            new JLabel("    Do not edit the text without clicking the buttons!");

        ActionButton deleteButton = new ActionButton(new DeleteCommand(textView));
        
        ActionButton insertButton = new ActionButton(new InsertCommand(textView));

        JButton redoButton = new JButton();
        redoButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                UnRedo.getInstance().redo();
            }
        });

        JButton undoButton = new JButton();
        undoButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                UnRedo.getInstance().undo();
            }
        });

        contentPane.setLayout(borderLayout);

        setSize(new Dimension(500, 300));

        setTitle("Text Editor 1.0");

        deleteButton.setToolTipText("Delete a character at the cursor");

        deleteButton.setText("Delete");

        insertButton.setText("Insert");

        insertButton.setToolTipText(
                "Insert a random character at the cursor");

        redoButton.setText("Redo");

        undoButton.setText("Undo");

        toolBar.add(deleteButton);

        toolBar.add(insertButton);

        toolBar.add(undoButton);

        toolBar.add(redoButton);

        toolBar.add(warningLabel);

        // textView.setEditable(false);
        scrollPane.getViewport().add(textView);

        contentPane.add(scrollPane, java.awt.BorderLayout.CENTER);

        contentPane.add(toolBar, BorderLayout.NORTH);

    }
}
