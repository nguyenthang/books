package designpattern.observer;

import java.util.Observable;
import java.util.Observer;

class Light implements Observer {

    public void update(Observable o, Object arg) {
        Door.DoorState doorState = (Door.DoorState) arg;
        if (doorState == Door.DoorState.OPEN) {
            turnOn();
        } else {
            turnOff();
        }
    }

    private void turnOn() {
        System.out.println("The light is turned on!");
    }

    private void turnOff() {
        System.out.println("The light is turned off!");
    }
}
