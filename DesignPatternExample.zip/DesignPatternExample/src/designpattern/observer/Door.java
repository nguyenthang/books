package designpattern.observer;

import java.util.Observable;

public class Door extends Observable {

    public enum DoorState {
        CLOSE,
        OPEN;
    }
    private DoorState state = DoorState.CLOSE;

    public DoorState getState() {
        return state;
    }

    public void setState(DoorState state) {
        if (state != this.state) {
            this.state = state;
            setChanged();
            notifyObservers(state);
        }
    }

    public void open() {
        System.out.println("The door is opening!");
        setState(DoorState.OPEN);
    }

    public void close() {
        System.out.println("The door is closing!");
        setState(DoorState.CLOSE);
    }
}
