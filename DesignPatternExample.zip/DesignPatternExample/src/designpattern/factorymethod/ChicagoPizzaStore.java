package designpattern.factorymethod;

public class ChicagoPizzaStore extends PizzaStore {

    protected Pizza createPizza() {
        return new ChicagoPizza();
    }
}

class ChicagoPizza implements Pizza {

    public ChicagoPizza() {
        // Create a Chicago specific pizza
        System.out.println("A ChicagoPizza created!");
    }
}

