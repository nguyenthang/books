package designpattern.decorator;

public class Decaf implements Beverage {

	@Override
	public String getDescription() {
		return "THis is a Decaf";
	}

	@Override
	public int getCost() {
		return 8;
	}

}
