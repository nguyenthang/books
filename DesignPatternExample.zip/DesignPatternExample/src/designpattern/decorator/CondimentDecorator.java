package designpattern.decorator;

public abstract class CondimentDecorator implements Beverage{
	private Beverage beverage;
	
	public CondimentDecorator(Beverage b) {
		this.beverage = b;
	}

	public Beverage getBeverage() {
		return beverage;
	}
}
