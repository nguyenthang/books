package designpattern.decorator;

public class Milk extends CondimentDecorator {
	private int myCost = 3;
	
	public Milk(Beverage b) {
		super(b);
	}
	
	
	@Override
	public String getDescription() {
		return null;
	}

	@Override
	public int getCost() {
		return getBeverage().getCost() + myCost;
	}

}
