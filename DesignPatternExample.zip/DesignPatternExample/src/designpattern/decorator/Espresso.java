package designpattern.decorator;

public class Espresso implements Beverage {
	String desc = "Espresso";

	public String getDescription() {
		return desc;
	}

	public int getCost() {
		return 10;
	}
}
