package designpattern.decorator;

public class Main {

	public static void main(String[] args) {
		// Decaf + Milk + Mocha
		Beverage base = new Decaf();
		Beverage plusMilk = new Milk(base);
		Beverage plusMilkMocha = new Mocha(plusMilk);
		
		System.out.println(plusMilkMocha.getCost());
	}
}
