package designpattern.decorator;

public class Mocha extends CondimentDecorator {

	private int myCost = 2;

	public Mocha(Beverage b) {
		super(b);
	}

	@Override
	public String getDescription() {
		return null;
	}

	@Override
	public int getCost() {
		return getBeverage().getCost() + myCost ;
	}
	

}
