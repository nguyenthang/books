package designpattern.decorator;

public interface Beverage {

public String getDescription();

public int getCost();
}
