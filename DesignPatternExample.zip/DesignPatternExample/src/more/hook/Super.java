package more.hook;

public class Super {

    protected void veryImportantInit() {
    }

    public void overrideable() {
        // How can we force overriding method
        // to have a call like this?
        veryImportantInit();

        // do something else
    }
}

class Sub extends Super {

    private void doSomething() {
    }

    @Override
    public void overrideable() {
        // Sorry! I forgot calling your
        // veryImportantInit method!

        doSomething();
    }
}

// -----------
class Super2 {

    protected void veryImportantInit() {
    }

    public final void aMethod() {
        // How can we force overriding method
        // to have a call like this?
        veryImportantInit();
        overrideable();
    }

    protected void overrideable() {
        // do something else
    }
}
